# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gridappsd_cim', 'gridappsd_cim.loaders']

package_data = \
{'': ['*'], 'gridappsd_cim.loaders': ['.ipynb_checkpoints/*']}

install_requires = \
['xsdata>=22.5,<23.0']

setup_kwargs = {
    'name': 'gridappsd-cim-models',
    'version': '0.1.0',
    'description': 'CIM models used within gridappsd.',
    'long_description': None,
    'author': 'C. Allwardt',
    'author_email': '3979063+craig8@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
