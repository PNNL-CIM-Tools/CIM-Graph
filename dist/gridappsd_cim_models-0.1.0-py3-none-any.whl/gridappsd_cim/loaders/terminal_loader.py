import os, json, time
from __future__ import annotations
from typing import List

from gridappsd import GridAPPSD, topics as t
from gridappsd_cim import Terminal, ConnectivityNode

class TopologyProcessor(GridAPPSD):
    
    def __init__(self):
        os.environ['GRIDAPPSD_APPLICATION_ID'] = 'gridappsd-cim-profile'
        os.environ['GRIDAPPSD_APPLICATION_STATUS'] = 'STARTED'
        os.environ['GRIDAPPSD_USER'] = 'app_user'
        os.environ['GRIDAPPSD_PASSWORD'] = '1234App'
        gapps = GridAPPSD()
        assert gapps.connected
        self.gapps = gapps
        self.log = self.gapps.get_logger()
        
        self.log.info('Terminal loader started')
        
    def load_terminal_by_connectivity_node(conducting: str | ConductingEquipment) -> List[Terminal]:
    